<?php

function conect(){

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "hotel";

    $conn = new mysqli($servername, $username, $password);

    mysqli_select_db($conn,$dbname);

    return $conn;

}
?>