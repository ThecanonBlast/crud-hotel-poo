<?php
    include("conection.php");
    $conn=conect();

    $id = $_POST['id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];

    $sql="UPDATE reservation SET `name`='$name',`phone`='$phone',`date`='$date' WHERE id='$id'";
    $query=mysqli_query($conn,$sql);

    if($query){
        header("location: home.php");
    }
?>