<?php
    include("conection.php");
    $conn=conect();

    $id = $_POST['id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];

    $sql="INSERT INTO reservation VALUES ('$id','$name','$phone','$date')";
    $query=mysqli_query($conn,$sql);

    if($query){
        header("location: home.php");
    }
?>