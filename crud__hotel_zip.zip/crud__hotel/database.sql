create database hotel;
use hotel;

CREATE TABLE reservation(
    id INT PRIMARY KEY,
    name VARCHAR(30),
    phone INT,
    date VARCHAR
);

CREATE TABLE account(
    id INT PRIMARY KEY,
    email VARCHAR(40),
    password_user INT,
);