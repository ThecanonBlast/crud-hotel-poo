<?php
    include("conection.php");
    $conn=conect();

    $id = $_GET['id'];

    $sql="DELETE FROM reservation WHERE id='$id'";
    $query=mysqli_query($conn,$sql);

    if($query){
        header("location: home.php");
    }
?>