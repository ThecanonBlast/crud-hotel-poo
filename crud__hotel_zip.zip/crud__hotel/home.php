<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD your hotel reservations</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <style>

  </style>
</head>

<body>
  <div class="container mt-4">
    <h1 class="text-center mb-4">HOTEL AA</h1>
    <form action="functions.php" method="post">
      <div class="row">
        <div class="col-md-2">
          <label for="idInput" class="form-label">ID</label>
          <input type="text" class="form-control" id="idInput" name="id" required>
        </div>
        <div class="col-md-3">
          <label for="nameInput" class="form-label">Name</label>
          <input type="text" class="form-control" id="nameInput" name="name" required>
        </div>
        <div class="col-md-3">
          <label for="phoneInput" class="form-label">Phone</label>
          <input type="text" class="form-control" id="phoneInput" name="phone" required>
        </div>
        <div class="col-md-3">
          <label for="dateInput" class="form-label">Date</label>
          <input type="text" class="form-control" id="dateInput" name="date" required>
        </div>
        <div class="col-md-1">
          <button type="submit" class="btn btn-dark mt-md-4">create</button>
        </div>
      </div>
    </form>

    <div class="col-md-10">
      <table class="table table-striped table-hover mt-4">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php
          while ($row =   $query->fetch_assoc()) {
          ?>
            <tr>
              <th><?php echo $row['id'] ?></th>
              <th><?php echo $row['name'] ?></th>
              <th><?php echo $row['phone'] ?></th>
              <th><?php echo $row['date'] ?></th>
              <th><a href="edit.php?id=<?php echo $row['id'] ?>" class="btn btn-dark">edit</a></th>
              <th><a href="delete.php?id=<?php echo $row['id'] ?>" class="btn btn-dark">delete</a></th>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>


    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.0/js/bootstrap.min.js"></script>
</body>

</html>